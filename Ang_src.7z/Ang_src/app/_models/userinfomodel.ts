export class Userinfomodel 
{
    _id: string;
    fullname: string;
    email: string;
    mobileno: string;
    country: string;
    english: string;
    bengali: string;
    hindi: string;
    language: string;
    gender: string;
    dob: string;
    password: string;
    address: string;
    regdate: string;
    regtime: string;
}
