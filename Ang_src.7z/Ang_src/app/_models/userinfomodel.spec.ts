import { Userinfomodel } from './userinfomodel';

describe('Userinfomodel', () => {
  it('should create an instance', () => {
    expect(new Userinfomodel()).toBeTruthy();
  });
});
