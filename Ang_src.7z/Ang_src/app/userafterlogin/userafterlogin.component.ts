import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userafterlogin',
  templateUrl: './userafterlogin.component.html',
  styleUrls: ['./userafterlogin.component.css']
})
export class UserafterloginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
