package com.example.racdb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestapicruddbApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestapicruddbApplication.class, args);
		System.out.println("MAIN METHOD.");
	}

}
